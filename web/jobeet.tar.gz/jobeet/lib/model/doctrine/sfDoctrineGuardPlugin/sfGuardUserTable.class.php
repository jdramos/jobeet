<?php

class sfGuardUserTable extends PluginsfGuardUserTable
{
}
