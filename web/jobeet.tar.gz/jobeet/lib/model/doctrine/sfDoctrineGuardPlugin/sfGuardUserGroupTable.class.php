<?php

class sfGuardUserGroupTable extends PluginsfGuardUserGroupTable
{
}
