<?php

class sfGuardRememberKeyTable extends PluginsfGuardRememberKeyTable
{
}
