<?php

class JobeetCategoryAffiliateTable extends Doctrine_Table
{
}
