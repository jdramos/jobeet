<?php

/**
 * sfGuardGroup module helper.
 *
 * @package    sfGuardPlugin
 * @subpackage sfGuardGroup
 * @author     Fabien Potencier
 * @version    SVN: $Id: sfGuardGroupGeneratorHelper.class.php 23319 2009-10-25 12:22:23Z Kris.Wallsmith $
 */
class sfGuardGroupGeneratorHelper extends BaseSfGuardGroupGeneratorHelper
{
}
