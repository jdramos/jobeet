<?php

/**
 * affiliate module helper.
 *
 * @package    jobeet
 * @subpackage affiliate
 * @author     Your name here
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class affiliateGeneratorHelper extends BaseAffiliateGeneratorHelper
{
}
