<h1>Edit Jobeet affiliate</h1>

<?php include_partial('form', array('form' => $form)) ?>
